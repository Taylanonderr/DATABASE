import java.sql.*;
public class IssueBookDao {
	
public static boolean checkBook(int bookcallno){
	boolean status=false;
	try{
		Connection con=DB.getConnection();
		PreparedStatement ps=con.prepareStatement("select * from books where callno=?");
		ps.setInt(1,bookcallno);
	    ResultSet rs=ps.executeQuery();
		status=rs.next();
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}

public static int save(int bookcallno,int studentid,String studentname,String studentcontact){
	int status=0;
	try{
		Connection con=DB.getConnection();
		
		status=updatebook(bookcallno);//updating quantity and issue
		if(status>0){
			PreparedStatement ps=con.prepareStatement("insert into issuebooks(bookcallno,studentid) values(?,?)");
			ps.setInt(1,bookcallno);
			ps.setInt(2,studentid);
			status=ps.executeUpdate();

			PreparedStatement ps1=con.prepareStatement("select studentid from students where studentid=?");
			ps1.setInt(1,studentid);
			ResultSet rs=ps1.executeQuery();

			if(rs.next()){
				status=Integer.parseInt(rs.getObject(1).toString());
			}
			System.out.println("status : "+status);
			if(status!=studentid) {
				PreparedStatement ps2 = con.prepareStatement("insert into students(studentid,studentname,studentcontact) values(?,?,?)");
				ps2.setInt(1, studentid);
				ps2.setString(2, studentname);
				ps2.setString(3, studentcontact);
				status = ps2.executeUpdate();
			}
		}
		
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
public static int updatebook(int bookcallno){
	int status=0;
	int quantity=0,issued=0;
	try{
		Connection con=DB.getConnection();
		System.out.println("geldi1");
		PreparedStatement ps=con.prepareStatement("select quantity from books where callno=?");
		ps.setInt(1,bookcallno);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			quantity=rs.getInt("quantity");
		}
		System.out.println("geldi2");

		if(quantity>0){
		PreparedStatement ps2=con.prepareStatement("update books set quantity=? where callno=?");
		ps2.setInt(1,quantity-1);
		ps2.setInt(2,bookcallno);
			System.out.println("geldi3");

			status=ps2.executeUpdate();
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
}
