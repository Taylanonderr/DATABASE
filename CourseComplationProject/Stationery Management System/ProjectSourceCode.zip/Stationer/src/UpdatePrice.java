import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UpdatePrice  extends JFrame {
        static UpdatePrice frame;
        private JPanel contentPane;
        private JTextField textField;
        private JTextField textField1;

        /**
         * Launch the application.
         */
        public static void main(String[] args) {
            EventQueue.invokeLater(new Runnable() {
                public void run() {
                    try {
                        frame = new UpdatePrice();
                        frame.setVisible(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }

    //TRIGGER after_update_insert BEFORE UPDATE ON products FOR EACH ROW BEGIN insert into processproductlog SET ProductId=NEW.productId , Message='Product table has changed with',totalSold=NEW.totalSoldAmount ,MessageDate=NEW.saleDate END

        /**
         * Create the frame.
         */
        public UpdatePrice() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 450, 300);
            contentPane = new JPanel();
            contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
            setContentPane(contentPane);

            JLabel lblEnterId = new JLabel("Enter Id:               ");
            textField = new JTextField();
            textField.setColumns(10);
            JLabel lblPrice = new JLabel("Enter new price:");
            textField1 = new JTextField();
            textField1.setColumns(10);

            JButton btnSell = new JButton("Update Price");
            btnSell.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String sid=textField.getText();
                    String priceUpdate=textField1.getText();
                    if(sid==null||sid.trim().equals("")){
                        JOptionPane.showMessageDialog(UpdatePrice.this,"Id can't be blank");
                    }
                    else if(priceUpdate==null || priceUpdate.trim().equals("")) {
                        JOptionPane.showMessageDialog(UpdatePrice.this, "Updated price can't be blank");
                    }
                    else{
                        int id=Integer.parseInt(sid);
                        int price=Integer.parseInt(priceUpdate);
                        int i=update(id,price);//DEĞİŞECEK
                        if(i>0){
                            JOptionPane.showMessageDialog(UpdatePrice.this,"Product price update successfully.");
                        }else{
                            JOptionPane.showMessageDialog(UpdatePrice.this,"Unable to update price given id product.!");
                        }
                    }
                }
            });
            btnSell.setFont(new Font("Tahoma", Font.PLAIN, 13));

            JButton btnNewButton = new JButton("Back");
            btnNewButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    StationerSuccess.main(new String[]{});
                    frame.dispose();
                }
            });
            btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
            GroupLayout gl_contentPane = new GroupLayout(contentPane);
            gl_contentPane.setHorizontalGroup(
                    gl_contentPane.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(gl_contentPane.createSequentialGroup()
                                    .addGap(39)
                                    .addComponent(lblEnterId)

                                    .addGap(57)
                                    .addComponent(textField, GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE)
                                    .addContainerGap(107, Short.MAX_VALUE))
                            .addGroup(gl_contentPane.createSequentialGroup()
                                    .addGap(39)
                                .addComponent(lblPrice)
                                .addGap(57)
                                .addComponent(textField1,  GroupLayout.PREFERRED_SIZE, 178, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(107, Short.MAX_VALUE))
                        .addGroup(GroupLayout.Alignment.TRAILING, gl_contentPane.createSequentialGroup()
                                    .addContainerGap(175, Short.MAX_VALUE)
                                    .addComponent(btnSell, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE)
                                    .addGap(140))
                            .addGroup(GroupLayout.Alignment.TRAILING, gl_contentPane.createSequentialGroup()
                                    .addContainerGap(322, Short.MAX_VALUE)
                                    .addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 92, GroupLayout.PREFERRED_SIZE)
                                    .addContainerGap())
            );
            gl_contentPane.setVerticalGroup(
                    gl_contentPane.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addGroup(gl_contentPane.createSequentialGroup()
                                    .addGap(19)
                                    .addGroup(gl_contentPane.createParallelGroup(GroupLayout.Alignment.LEADING)
                                            .addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblEnterId))
                                    .addGap(19)
                                    .addGroup(gl_contentPane.createParallelGroup(GroupLayout.Alignment.LEADING)
                                            .addComponent(textField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblPrice))
                                    .addGap(33)
                                    .addComponent(btnSell, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
                                    .addGap(43)
                                    .addComponent(btnNewButton)
                                    .addContainerGap(78, Short.MAX_VALUE))
            );
            contentPane.setLayout(gl_contentPane);
        }

    public static int update(int callNo ,int price){
        int status=0;
        try{
            Connection con=DB.getConnection();
            SimpleDateFormat bicim=new SimpleDateFormat("dd/M/yyyy");
            Date tarih=new Date();
            String saleDate=bicim.format(tarih);
            /*Sadece ilk triggerı oluştururken koddan kullandım.Sonra aynı sorguyu sql içerisine koydum.*/
           /* Statement stmt = con.createStatement();
            stmt.executeUpdate("CREATE TRIGGER after_update_insert AFTER UPDATE ON products " //
                    + "FOR EACH ROW "//
                    + "BEGIN "//
                    + "insert into processproductlog SET ProductId=NEW.productId , Message='MesajEklendi',totalSold=NEW.totalSoldAmount ,MessageDate=NEW.saleDate; "//
                    + "END;" //
            );*/

            PreparedStatement ps=con.prepareStatement("update products set price=? where productId=?");
            ps.setInt(1,price);
            ps.setInt(2,callNo);
            status=ps.executeUpdate();

            con.close();
        }catch(Exception e){System.out.println(e);}
        return status;
    }
    }

