import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StationerSuccess  extends JFrame {
        static StationerSuccess frame;
        private JPanel contentPane;

        /**
         * Launch the application.
         */
        public static void main(String[] args) {
            EventQueue.invokeLater(new Runnable() {
                public void run() {
                    try {
                        frame = new StationerSuccess();
                        frame.setVisible(true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }

        /**
         * Create the frame.
         */
        public StationerSuccess() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 450, 433);
            contentPane = new JPanel();
            contentPane.setForeground(Color.GRAY);
            contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
            setContentPane(contentPane);

            JLabel lblLibrarianSection = new JLabel("Stationer Section        -");
            lblLibrarianSection.setFont(new Font("Tahoma", Font.PLAIN, 22));

            JButton btnNewProduct = new JButton("Add Product");
            btnNewProduct.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    ProductsForm.main(new String[]{});
                    frame.dispose();
                }
            });
            btnNewProduct.setFont(new Font("Tahoma", Font.PLAIN, 13));

            JButton btnViewProduct = new JButton("View Product");
            btnViewProduct.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent arg0) {
                    ViewProducts.main(new String[]{});
                }
            });
            btnViewProduct.setFont(new Font("Tahoma", Font.PLAIN, 13));

            JButton btnSellProduct = new JButton("Sell Product");
            btnSellProduct.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    SellProduct.main(new String[]{});
                    frame.dispose();
                }
            });
            btnSellProduct.setFont(new Font("Tahoma", Font.PLAIN, 13));

            JButton btnViewSelledBooks = new JButton("View Selled Products");
            btnViewSelledBooks.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    ViewSelledProducts.main(new String[]{});
                }
            });
            btnViewSelledBooks.setFont(new Font("Tahoma", Font.PLAIN, 13));

            JButton btnReturnBook = new JButton("Update Prices");
            btnReturnBook.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    UpdatePrice.main(new String[]{});
                    frame.dispose();
                }
            });
            btnReturnBook.setFont(new Font("Tahoma", Font.PLAIN, 13));

            JButton btnLogout = new JButton("Logout");
            btnLogout.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Company.main(new String[]{});
                    frame.dispose();
                }
            });
            btnLogout.setFont(new Font("Tahoma", Font.PLAIN, 13));
            GroupLayout gl_contentPane = new GroupLayout(contentPane);
            gl_contentPane.setHorizontalGroup(
                    gl_contentPane.createParallelGroup(Alignment.LEADING)
                            .addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
                                    .addContainerGap(81, Short.MAX_VALUE)
                                    .addComponent(lblLibrarianSection)
                                    .addGap(54))
                            .addGroup(gl_contentPane.createSequentialGroup()
                                    .addGap(132)
                                    .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                            .addComponent(btnLogout, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnReturnBook, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnViewSelledBooks, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnSellProduct, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnViewProduct, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnNewProduct, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE))
                                    .addContainerGap(101, Short.MAX_VALUE))
            );
            gl_contentPane.setVerticalGroup(
                    gl_contentPane.createParallelGroup(Alignment.LEADING)
                            .addGroup(gl_contentPane.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(lblLibrarianSection)
                                    .addGap(18)
                                    .addComponent(btnNewProduct, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18)
                                    .addComponent(btnViewProduct, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18)
                                    .addComponent(btnSellProduct, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18)
                                    .addComponent(btnViewSelledBooks, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18)
                                    .addComponent(btnReturnBook, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                                    .addGap(18)
                                    .addComponent(btnLogout, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                                    .addContainerGap(16, Short.MAX_VALUE))
            );
            contentPane.setLayout(gl_contentPane);
        }

    }


