
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class ProductDao {
        public static int save(int callNo ,String productName,int price,int amount,String saleDate){
            int status=0;
            try{
                Connection con=DB.getConnection();
                PreparedStatement ps=con.prepareStatement("insert into products(productId,productName,price,amount,totalSoldAmount,saleDate) values(?,?,?,?,?,?)");

                ps.setInt(1,callNo);
                ps.setString(2,productName);
                ps.setInt(3,price);
                ps.setInt(4,amount);
                ps.setInt(5,0);
                ps.setString(6,saleDate);
                status=ps.executeUpdate();
                con.close();
            }catch(Exception e){System.out.println(e);}
            return status;
        }
    public static int update(int callNo ,int amount){
        int status=0;
        try{
            Connection con=DB.getConnection();
            SimpleDateFormat bicim=new SimpleDateFormat("dd/M/yyyy");
            Date tarih=new Date();
            String saleDate=bicim.format(tarih);
            /*Sadece ilk triggerı oluştururken koddan kullandım.Sonra aynı sorguyu sql içerisine koydum.*/
           /* Statement stmt = con.createStatement();
            stmt.executeUpdate("CREATE TRIGGER after_update_insert AFTER UPDATE ON products " //
                    + "FOR EACH ROW "//
                    + "BEGIN "//
                    + "insert into processproductlog SET ProductId=NEW.productId , Message='MesajEklendi',totalSold=NEW.totalSoldAmount ,MessageDate=NEW.saleDate; "//
                    + "END;" //
            );*/

            PreparedStatement ps=con.prepareStatement("update products set totalSoldAmount=totalSoldAmount+?,saleDate=? where productId=?");
            ps.setInt(1,amount);
            ps.setString(2,saleDate);
            ps.setInt(3,callNo);
            status=ps.executeUpdate();

            con.close();
        }catch(Exception e){System.out.println(e);}
        return status;
    }
}
